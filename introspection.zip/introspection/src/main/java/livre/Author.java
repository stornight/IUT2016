package livre;

public class Author {

	public String firstName;
	public String lastName;
}
