package livre;

import static org.junit.Assert.*;

import org.junit.Test;

public class ParsToJsonTest {

	ParsToJson j = new ParsToJson();
	@Test
	public void testOjectReturnWithCurlybrace() {
		// Given
		
		String s="merde";
		Book book = new Book();
		book.titre = "gof";
		Author auteur= new Author();
		Author fu = new Author();
		auteur.firstName="jean";
		auteur.lastName="cule";
		fu.firstName="nike";
		fu.lastName="tamere";
		
		book.aut.add(auteur);
		book.aut.add(fu);

		// When
		String res = j.toJson(book);
		// Then
		System.out.println(res);
		String expected = "{\"titre\": \"gof\", \"aut\": [{\"firstName\": \"jean\", \"lastName\": \"cule\"}], [{\"firstName\": \"nike\", \"lastName\": \"tamere\"}]}";
		assertEquals(expected, res);
	}

}
