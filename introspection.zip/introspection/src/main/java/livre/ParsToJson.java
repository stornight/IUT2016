package livre;

import java.lang.reflect.Field;
import java.util.Collection;

import org.json.simple.JSONObject;

public class ParsToJson {
	
	public String toJson(Object o){
		if(o==null){
			return null;
		}
		Class<? extends Object> c = o.getClass();
		StringBuilder sb = new StringBuilder("{");
		int i =0;
		for(Field f : c.getFields()){
			sb.append("\""+f.getName()+"\": ");
			Object val;

			try {
				val = f.get(o);
				if(val instanceof String){
					sb.append("\""+val+"\"");
				}
				else if(val instanceof Collection<?>){
					int y = 0;
					for(Object ob :  ((Collection<?>) val).toArray()){
						sb.append("["+toJson(ob)+"]");
						if(y<((Collection<?>) val).toArray().length-1){
							sb.append(", ");
						}
						y++;
					}
				}
				else if(val instanceof Object){
					sb.append("["+toJson(val)+"]");
				}
				
				else{
					sb.append(val);
				}
				if(i<c.getFields().length-1){
					sb.append(", ");		
				}

				i++;
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		sb.append("}");
		
		return sb.toString();
	}

}
