package livre;

import java.util.ArrayList;

public class Book {
	public String titre;
	public ArrayList<Author> aut= new ArrayList<>();
}
